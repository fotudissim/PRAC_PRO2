var searchData=
[
  ['node_0',['Node',['../structBinTree_1_1Node.html',1,'BinTree']]]
];
