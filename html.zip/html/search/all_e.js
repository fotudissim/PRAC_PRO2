var searchData=
[
  ['valida_0',['valida',['../classRejilla.html#aafe642d35e8a72c7ecb01301c5942f2d',1,'Rejilla']]]
];
