var searchData=
[
  ['dim_0',['dim',['../classRejilla.html#a4786770c78ba0dca247cd9ccbafa0ef5',1,'Rejilla']]]
];
