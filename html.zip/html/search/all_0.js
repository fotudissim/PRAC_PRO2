var searchData=
[
  ['add_5fmsg_0',['add_msg',['../classMensajes.html#a8ba26d2e5f1fa963e27308e5331401b1',1,'Mensajes']]],
  ['add_5fpatron_1',['add_patron',['../classPatrones.html#aeeb487fe89d2b8e5f38a61f256461162',1,'Patrones']]],
  ['add_5frejilla_2',['add_rejilla',['../classRejillas.html#a6f5eaafe0dfcff3ef35e3b87d3a32b10',1,'Rejillas']]]
];
