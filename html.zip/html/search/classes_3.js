var searchData=
[
  ['patron_0',['Patron',['../classPatron.html',1,'']]],
  ['patrones_1',['Patrones',['../classPatrones.html',1,'']]]
];
