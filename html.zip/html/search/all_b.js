var searchData=
[
  ['out_5fim_5fpatron_0',['out_im_patron',['../classPatron.html#aaaee90f59da44e821b8c15cd58dac2d2',1,'Patron']]]
];
