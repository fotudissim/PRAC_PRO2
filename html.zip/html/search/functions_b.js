var searchData=
[
  ['recorrearb_0',['recorreArb',['../classPatron.html#a66a715a6d590a47ba423f03b6cb86d15',1,'Patron']]],
  ['rejilla_1',['Rejilla',['../classRejilla.html#a0d4c2d54277ee3862d53d0f673ac8783',1,'Rejilla::Rejilla()'],['../classRejilla.html#a1b3fc7a0ac688bc31ff95aa54d1537ba',1,'Rejilla::Rejilla(int n, int npos)']]],
  ['rejillas_2',['Rejillas',['../classRejillas.html#a966e7a4e132d5f8939e17a93ba0f9d1a',1,'Rejillas']]],
  ['ret_5fcolumna_3',['ret_columna',['../classRejilla.html#a3d9b89ef4a7adaec47f248f46d338fe9',1,'Rejilla']]],
  ['ret_5fcontenido_4',['ret_contenido',['../classMensaje.html#abd38a249fac03fa1815969b751e6232d',1,'Mensaje']]],
  ['ret_5fdim_5',['ret_dim',['../classRejilla.html#ae3d0bd306bd785d2bee45d798ae49545',1,'Rejilla']]],
  ['ret_5ffila_6',['ret_fila',['../classRejilla.html#a59ace49babfd7a0a7cb0cea26bd808ab',1,'Rejilla']]],
  ['ret_5fidm_7',['ret_idm',['../classMensaje.html#a50b7553c1be3ef442b1d6c21435dce52',1,'Mensaje']]],
  ['ret_5fk_8',['ret_k',['../classRejilla.html#a40a2fd1c1a6377d6d35306fb146b066d',1,'Rejilla']]],
  ['ret_5flongitud_9',['ret_longitud',['../classMensaje.html#a797ffafc2e4f8d1c5ffef285d9e5c761',1,'Mensaje']]],
  ['ret_5fmsg_10',['ret_msg',['../classMensajes.html#ad922f23a55cd7294cb9dc23cf69581a9',1,'Mensajes']]]
];
