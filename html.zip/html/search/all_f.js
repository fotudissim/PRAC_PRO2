var searchData=
[
  ['_7epatron_0',['~Patron',['../classPatron.html#a79ef889c74a5444af10bb08243b06d99',1,'Patron']]]
];
