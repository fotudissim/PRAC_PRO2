var searchData=
[
  ['k_0',['k',['../classRejilla.html#a06976c375224770a3274c1d544c6ec24',1,'Rejilla']]]
];
