var searchData=
[
  ['borrar_5fmsg_0',['borrar_msg',['../classMensajes.html#acb4f5ac154f932c421e9e5b584fb6764',1,'Mensajes']]]
];
