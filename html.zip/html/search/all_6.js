var searchData=
[
  ['id_0',['id',['../classMensaje.html#adf45855e57e91c07f7ae0c636be07bab',1,'Mensaje']]],
  ['inicializar_5fptr_1',['inicializar_ptr',['../classPatron.html#aba7a743e9c3ad9011129ea7b2e396d10',1,'Patron']]],
  ['init_5fptr_5fim_2',['init_ptr_im',['../classPatron.html#a2ebe069a7b6fea9772d6c40ec47ea0b6',1,'Patron']]]
];
