var searchData=
[
  ['node_0',['Node',['../structBinTree_1_1Node.html',1,'BinTree']]],
  ['num_5fmsg_1',['num_msg',['../classMensajes.html#a5f4a46b8bada2eacf2cf305e3baeb9c2',1,'Mensajes']]],
  ['num_5fptr_2',['num_ptr',['../classPatrones.html#aba1b0d75511211f71fdfeb482f760b48',1,'Patrones']]],
  ['num_5frejillas_3',['num_rejillas',['../classRejillas.html#a20d4fd487cb999dae7cfb2855ec09641',1,'Rejillas']]]
];
