var indexSectionsWithContent =
{
  0: "abcdehiklmnoprv~",
  1: "bmnpr",
  2: "mpr",
  3: "abcdeilmnoprv~",
  4: "cdhikm",
  5: "ep"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables",
  5: "Páginas"
};

