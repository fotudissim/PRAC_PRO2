var searchData=
[
  ['id_0',['id',['../classMensaje.html#adf45855e57e91c07f7ae0c636be07bab',1,'Mensaje']]]
];
